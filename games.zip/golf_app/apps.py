from django.apps import AppConfig


class GolfAppConfig(AppConfig):
    name = 'golf_app'
