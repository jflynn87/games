from django.apps import AppConfig


class PortAppConfig(AppConfig):
    name = 'port_app'
