from django.apps import AppConfig


class RunAppConfig(AppConfig):
    name = 'run_app'
