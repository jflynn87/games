from django.contrib import admin
from run_app.models import Shoes, Run, Schedule, Plan

# Register your models here.

admin.site.register(Shoes)
admin.site.register(Run)
admin.site.register(Plan)
admin.site.register(Schedule)
