from django.apps import AppConfig


class FbAppConfig(AppConfig):
    name = 'fb_app'
