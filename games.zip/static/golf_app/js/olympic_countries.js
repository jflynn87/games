$('#pick_form').ready(function () {
   if ($('#pga_t_num').text() == 999) {
         console.log('olympics')
                                            }
    
    
        $('#mens_countries').append('<p>' + 'Gold:' + '</p>')
        $('#mens_countries').append('<p>' + 'Silver:' + '</p>')
        $('#mens_countries').append('<p>' + 'Bronze:' + '</p>')
        $('#womens_countries').append('<p>' + 'Gold:' + '</p>')
        $('#womens_countries').append('<p>' + 'Silver:' + '</p>')
        $('#womens_countries').append('<p>' + 'Bronze:' + '</p>')
    
})
