$(document).ready(function () {
    console.log('connected')
    
})