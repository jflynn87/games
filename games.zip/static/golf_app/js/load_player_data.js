$(document).ready(function() {
    console.log('player data ok')
    $('#test-body').append('<p>test</p> <p>test1 </p> <p>test2</p>')
    $('#test-container').addClass('player-background')
    $('#test-footer').addClass('player-footer')

})

